import React from 'react';
import { Link } from 'react-router-dom';
import { Film, User, UserCog } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-red-600 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Film className="h-8 w-8" />
            <span className="text-xl font-bold">BookMyShow</span>
          </Link>
          <div className="flex space-x-4">
            <Link to="/user-login" className="flex items-center space-x-1 hover:text-gray-200">
              <User className="h-5 w-5" />
              <span>User Login</span>
            </Link>
            <Link to="/employee-login" className="flex items-center space-x-1 hover:text-gray-200">
              <UserCog className="h-5 w-5" />
              <span>Employee Login</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;