import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import UserLogin from './pages/UserLogin';
import EmployeeLogin from './pages/EmployeeLogin';
import MoviePage from './pages/MoviePage';
import SeatSelection from './pages/SeatSelection';
import Payment from './pages/Payment';
import AddMovie from './pages/AddMovie';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <Navbar />
        <Routes>
          <Route path="/" element={<MoviePage />} />
          <Route path="/user-login" element={<UserLogin />} />
          <Route path="/employee-login" element={<EmployeeLogin />} />
          <Route path="/seat-selection" element={<SeatSelection />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/add-movie" element={<AddMovie />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;