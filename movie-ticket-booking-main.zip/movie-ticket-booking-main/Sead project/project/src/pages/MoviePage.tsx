import React, { useState } from 'react';
import { Star, Clock, Calendar, MapPin, Plus, ThumbsUp, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const theaters = [
  {
    id: 1,
    name: "PVR Cinemas",
    location: "Phoenix Mall",
    distance: "2.5 km",
    facilities: ["Dolby Atmos", "4K Projection", "Recliner Seats"],
    showTimes: [
      { time: "10:00 AM", price: 150, type: "Regular" },
      { time: "1:30 PM", price: 200, type: "Regular" },
      { time: "4:45 PM", price: 250, type: "Premium" },
      { time: "8:00 PM", price: 300, type: "Premium" }
    ]
  },
  {
    id: 2,
    name: "INOX",
    location: "Central Mall",
    distance: "3.8 km",
    facilities: ["IMAX", "Dolby Sound", "Luxury Seating"],
    showTimes: [
      { time: "11:15 AM", price: 180, type: "Regular" },
      { time: "2:45 PM", price: 220, type: "Regular" },
      { time: "6:15 PM", price: 280, type: "Premium" },
      { time: "9:30 PM", price: 320, type: "Premium" }
    ]
  },
  {
    id: 3,
    name: "Cinepolis",
    location: "City Center",
    distance: "4.2 km",
    facilities: ["3D Screens", "Gourmet Food", "VIP Lounge"],
    showTimes: [
      { time: "9:30 AM", price: 160, type: "Regular" },
      { time: "12:45 PM", price: 210, type: "Regular" },
      { time: "4:00 PM", price: 260, type: "Premium" },
      { time: "7:30 PM", price: 310, type: "Premium" }
    ]
  }
];

const movies = [
  {
    id: 1,
    title: "Dune: Part Two",
    image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    rating: 4.5,
    duration: "2h 46m",
    genre: "Sci-Fi/Adventure",
    reviews: [
      { user: "John D.", rating: 5, comment: "Masterpiece of sci-fi cinema!", likes: 234 },
      { user: "Sarah M.", rating: 4, comment: "Visually stunning!", likes: 186 }
    ],
    languages: ["English", "Hindi", "Tamil"],
    certifications: ["Dolby Atmos", "IMAX"]
  },
  {
    id: 2,
    title: "Poor Things",
    image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
    rating: 4.3,
    duration: "2h 21m",
    genre: "Drama/Comedy",
    reviews: [
      { user: "Mike R.", rating: 4.5, comment: "Brilliant performances!", likes: 156 },
      { user: "Emma L.", rating: 4, comment: "Unique and captivating", likes: 142 }
    ],
    languages: ["English", "Hindi"],
    certifications: ["4K", "Dolby Sound"]
  }
];

const MoviePage = () => {
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [showTheaters, setShowTheaters] = useState(false);
  const [selectedTheater, setSelectedTheater] = useState(null);
  const [selectedShowTime, setSelectedShowTime] = useState(null);
  const [showReviews, setShowReviews] = useState({});

  const handleBooking = (movie) => {
    setSelectedMovie(movie);
    setShowTheaters(true);
  };

  const handleTheaterSelect = (theater, showTime) => {
    setSelectedTheater(theater);
    setSelectedShowTime(showTime);
  };

  const toggleReviews = (movieId) => {
    setShowReviews(prev => ({
      ...prev,
      [movieId]: !prev[movieId]
    }));
  };

  const proceedToSeatSelection = () => {
    localStorage.setItem('bookingDetails', JSON.stringify({
      movie: selectedMovie,
      theater: selectedTheater,
      showTime: selectedShowTime
    }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Now Showing</h1>
        {localStorage.getItem('userType') === 'employee' && (
          <Link
            to="/add-movie"
            className="flex items-center bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition duration-200"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add New Movie
          </Link>
        )}
      </div>

      {!showTheaters ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {movies.map((movie) => (
            <div key={movie.id} className="bg-white rounded-lg shadow-md overflow-hidden">
              <img
                src={movie.image}
                alt={movie.title}
                className="w-full h-64 object-cover"
              />
              <div className="p-4">
                <h2 className="text-xl font-bold mb-2">{movie.title}</h2>
                <div className="flex items-center space-x-4 mb-2">
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 mr-1" />
                    <span>{movie.rating}/5</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-gray-500 mr-1" />
                    <span>{movie.duration}</span>
                  </div>
                </div>
                <p className="text-gray-600 mb-2">{movie.genre}</p>
                
                <div className="mb-3">
                  <div className="flex flex-wrap gap-2 mb-2">
                    {movie.languages.map((lang) => (
                      <span key={lang} className="px-2 py-1 bg-gray-100 rounded-full text-sm">
                        {lang}
                      </span>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {movie.certifications.map((cert) => (
                      <span key={cert} className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                        {cert}
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => toggleReviews(movie.id)}
                  className="flex items-center text-gray-600 mb-3 hover:text-gray-800"
                >
                  <MessageCircle className="h-4 w-4 mr-1" />
                  Show Reviews
                </button>

                {showReviews[movie.id] && (
                  <div className="mb-4 space-y-3">
                    {movie.reviews.map((review, idx) => (
                      <div key={idx} className="bg-gray-50 p-3 rounded-md">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{review.user}</span>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 mr-1" />
                            <span>{review.rating}</span>
                          </div>
                        </div>
                        <p className="text-sm text-gray-600">{review.comment}</p>
                        <div className="flex items-center mt-2 text-sm text-gray-500">
                          <ThumbsUp className="h-4 w-4 mr-1" />
                          {review.likes}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <button
                  onClick={() => handleBooking(movie)}
                  className="block w-full bg-red-600 text-white text-center py-2 rounded-md hover:bg-red-700 transition duration-200"
                >
                  Book Now
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div>
          <button
            onClick={() => setShowTheaters(false)}
            className="mb-4 text-red-600 hover:text-red-700 flex items-center"
          >
            ← Back to Movies
          </button>
          <h2 className="text-2xl font-bold mb-4">Select Theater for {selectedMovie?.title}</h2>
          <div className="space-y-4">
            {theaters.map((theater) => (
              <div key={theater.id} className="bg-white p-4 rounded-lg shadow-md">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold">{theater.name}</h3>
                    <div className="flex items-center text-gray-600 mt-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>{theater.location}</span>
                      <span className="mx-2">•</span>
                      <span>{theater.distance}</span>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {theater.facilities.map((facility) => (
                        <span key={facility} className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                          {facility}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {theater.showTimes.map((show) => (
                    <button
                      key={show.time}
                      onClick={() => handleTheaterSelect(theater, show)}
                      className={`px-4 py-2 rounded-md border ${
                        selectedTheater === theater && selectedShowTime === show
                          ? 'bg-red-600 text-white border-red-600'
                          : 'border-gray-300 hover:border-red-600'
                      }`}
                    >
                      <div className="text-sm">{show.time}</div>
                      <div className={`text-xs ${
                        selectedTheater === theater && selectedShowTime === show
                          ? 'text-white'
                          : 'text-gray-500'
                      }`}>
                        ₹{show.price} • {show.type}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          {selectedTheater && selectedShowTime && (
            <Link
              to="/seat-selection"
              onClick={proceedToSeatSelection}
              className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-red-600 text-white px-8 py-3 rounded-md hover:bg-red-700 transition duration-200 shadow-lg"
            >
              Continue to Seat Selection
            </Link>
          )}
        </div>
      )}
    </div>
  );
};

export default MoviePage;