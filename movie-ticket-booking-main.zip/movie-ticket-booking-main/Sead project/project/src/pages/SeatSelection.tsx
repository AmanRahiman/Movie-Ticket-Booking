import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Info } from 'lucide-react';

const SeatSelection = () => {
  const navigate = useNavigate();
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);

  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
  const seatsPerRow = 12;

  // Simulated occupied seats
  const occupiedSeats = ['A3', 'A4', 'B7', 'B8', 'C5', 'D10', 'E2', 'F6'];

  // Premium rows (first two rows from the back)
  const premiumRows = ['F', 'G'];

  const getSeatPrice = (row: string) => {
    return premiumRows.includes(row) ? 350 : 250;
  };

  const handleSeatClick = (seatId: string) => {
    if (occupiedSeats.includes(seatId)) return;

    setSelectedSeats(prev =>
      prev.includes(seatId)
        ? prev.filter(id => id !== seatId)
        : [...prev, seatId]
    );
  };

  const getTotalPrice = () => {
    return selectedSeats.reduce((total, seat) => {
      const row = seat.charAt(0);
      return total + getSeatPrice(row);
    }, 0);
  };

  const handleProceedToPayment = () => {
    if (selectedSeats.length > 0) {
      // Store seat selection details
      localStorage.setItem('seatSelection', JSON.stringify({
        seats: selectedSeats,
        totalPrice: getTotalPrice()
      }));
      navigate('/payment');
    }
  };

  const getSeatClass = (row: string, seatId: string) => {
    const baseClass = "w-8 h-8 rounded transition-all duration-200 flex items-center justify-center text-sm";
    
    if (occupiedSeats.includes(seatId)) {
      return `${baseClass} bg-gray-300 cursor-not-allowed opacity-50`;
    }
    
    if (selectedSeats.includes(seatId)) {
      return `${baseClass} bg-red-600 text-white`;
    }
    
    if (premiumRows.includes(row)) {
      return `${baseClass} bg-purple-100 hover:bg-purple-200`;
    }
    
    return `${baseClass} bg-gray-200 hover:bg-gray-300`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8 text-center">Select Your Seats</h1>
      
      <div className="mb-8">
        <div className="w-full h-8 bg-gray-800 rounded-t-lg text-center text-white text-sm py-1">
          Screen
        </div>
      </div>

      <div className="flex justify-center gap-8 mb-6">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-gray-200 rounded"></div>
          <span className="text-sm">Available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-red-600 rounded"></div>
          <span className="text-sm">Selected</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-gray-300 opacity-50 rounded"></div>
          <span className="text-sm">Occupied</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-purple-100 rounded"></div>
          <span className="text-sm">Premium</span>
        </div>
      </div>

      <div className="space-y-4 mb-8">
        {rows.map(row => (
          <div key={row} className="flex justify-center space-x-2">
            <div className="w-6 text-center font-medium">{row}</div>
            <div className="flex space-x-2">
              {Array.from({ length: seatsPerRow }, (_, i) => {
                const seatId = `${row}${i + 1}`;
                return (
                  <button
                    key={seatId}
                    className={getSeatClass(row, seatId)}
                    onClick={() => handleSeatClick(seatId)}
                    disabled={occupiedSeats.includes(seatId)}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      <div className="bg-white p-4 rounded-lg shadow-md">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold">Selected Seats</h3>
            <p className="text-gray-600">{selectedSeats.join(', ') || 'None selected'}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Total Amount</p>
            <p className="text-2xl font-bold">₹{getTotalPrice()}</p>
          </div>
        </div>

        <div className="bg-blue-50 p-3 rounded-md mb-4 flex items-start gap-2">
          <Info className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-blue-800">
            Premium seats (rows F-G) cost ₹350 each. Regular seats cost ₹250 each.
            Convenience fees and taxes will be added at payment.
          </p>
        </div>

        <button
          onClick={handleProceedToPayment}
          disabled={selectedSeats.length === 0}
          className={`w-full py-3 rounded-md ${
            selectedSeats.length > 0
              ? 'bg-red-600 text-white hover:bg-red-700'
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          } transition duration-200`}
        >
          {selectedSeats.length > 0 ? 'Proceed to Payment' : 'Select seats to continue'}
        </button>
      </div>
    </div>
  );
};

export default SeatSelection;