import React, { useState, useEffect } from 'react';
import { CreditCard, Calendar, Lock, Clock, Receipt, Shield } from 'lucide-react';

const Payment = () => {
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [name, setName] = useState('');
  const [bookingDetails, setBookingDetails] = useState<any>(null);
  const [seatDetails, setSeatDetails] = useState<any>(null);

  useEffect(() => {
    const booking = JSON.parse(localStorage.getItem('bookingDetails') || '{}');
    const seats = JSON.parse(localStorage.getItem('seatSelection') || '{}');
    setBookingDetails(booking);
    setSeatDetails(seats);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle payment processing
  };

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    const matches = v.match(/\d{4,16}/g);
    const match = (matches && matches[0]) || '';
    const parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length) {
      return parts.join(' ');
    } else {
      return value;
    }
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = formatCardNumber(e.target.value);
    setCardNumber(value);
  };

  const calculateTotal = () => {
    const basePrice = seatDetails?.totalPrice || 0;
    const convenienceFee = Math.round(basePrice * 0.0175); // 1.75% convenience fee
    const gst = Math.round((basePrice + convenienceFee) * 0.18); // 18% GST
    return {
      basePrice,
      convenienceFee,
      gst,
      total: basePrice + convenienceFee + gst
    };
  };

  const priceBreakdown = calculateTotal();

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-100 py-8">
      <div className="bg-white p-8 rounded-lg shadow-md w-full max-w-4xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-2xl font-bold mb-6">Payment Details</h2>
            
            <div className="mb-6 p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center mb-3">
                <Clock className="h-5 w-5 text-blue-600 mr-2" />
                <span className="font-semibold">Booking Summary</span>
              </div>
              <div className="space-y-2 text-sm">
                <p><strong>Movie:</strong> {bookingDetails?.movie?.title}</p>
                <p><strong>Theater:</strong> {bookingDetails?.theater?.name}</p>
                <p><strong>Show Time:</strong> {bookingDetails?.showTime?.time}</p>
                <p><strong>Seats:</strong> {seatDetails?.seats?.join(', ')}</p>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Card Holder Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                  placeholder="John Doe"
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Card Number</label>
                <div className="relative">
                  <CreditCard className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    className="pl-10 w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Expiry Date</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input
                      type="text"
                      value={expiryDate}
                      onChange={(e) => setExpiryDate(e.target.value)}
                      className="pl-10 w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="MM/YY"
                      maxLength={5}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">CVV</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <input
                      type="password"
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value)}
                      className="pl-10 w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="123"
                      maxLength={3}
                      required
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-red-600 text-white py-3 rounded-md hover:bg-red-700 transition duration-200 mt-6"
              >
                Pay ₹{priceBreakdown.total}
              </button>
            </form>
          </div>

          <div className="bg-gray-50 p-6 rounded-lg">
            <div className="flex items-center mb-4">
              <Receipt className="h-5 w-5 text-gray-600 mr-2" />
              <h3 className="text-lg font-semibold">Price Breakdown</h3>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>Base Price</span>
                <span>₹{priceBreakdown.basePrice}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>Convenience Fee</span>
                <span>₹{priceBreakdown.convenienceFee}</span>
              </div>
              <div className="flex justify-between text-sm text-gray-600">
                <span>GST (18%)</span>
                <span>₹{priceBreakdown.gst}</span>
              </div>
              <div className="border-t pt-3 mt-3">
                <div className="flex justify-between font-bold">
                  <span>Total Amount</span>
                  <span>₹{priceBreakdown.total}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 space-y-4">
              <div className="flex items-start gap-3 p-3 bg-green-50 rounded-md">
                <Shield className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-green-800">
                  <p className="font-semibold">Secure Payment</p>
                  <p>Your payment information is encrypted and secure.</p>
                </div>
              </div>

              <div className="text-xs text-gray-500">
                <p>By proceeding with the payment, you agree to our terms and conditions.</p>
                <p className="mt-1">Refund policy: Cancellation available up to 4 hours before show time.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;